<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['dark' => ($appearance ?? 'system') == 'dark']); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <meta name="description" content="<?php echo e($appSettings['seo_description'] ?? ''); ?>">
        <meta name="keywords" content="<?php echo e($appSettings['seo_keywords'] ?? ''); ?>">

        <meta property="og:title" content="<?php echo e($appSettings['seo_og_title'] ?? ''); ?>">
        <meta property="og:description" content="<?php echo e($appSettings['seo_og_description'] ?? ''); ?>">
        <meta property="og:image" content="<?php echo e(($appSettings['seo_og_image'] ?? '') ? asset('storage/' . $appSettings['seo_og_image']) : ''); ?>">

        <meta name="twitter:title" content="<?php echo e($appSettings['seo_twitter_title'] ?? ''); ?>">
        <meta name="twitter:description" content="<?php echo e($appSettings['seo_twitter_description'] ?? ''); ?>">
        <meta name="twitter:image" content="<?php echo e(($appSettings['seo_twitter_image'] ?? '') ? asset('storage/' . $appSettings['seo_twitter_image']) : ''); ?>">

        
        <script>
            (function() {
                const appearance = '<?php echo e($appearance ?? "system"); ?>';
                const bg = '<?php echo e($appSettings["site_base_color"] ?? "#852ba6"); ?>';
                const text = "#FFFFFF";

                if (appearance === 'system') {
                    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;

                    if (prefersDark) {
                        document.documentElement.classList.add('dark');
                    }
                }
                document.documentElement.style.setProperty("--selection-bg", bg);
                document.documentElement.style.setProperty("--selection-text", text);
            })();
        </script>

        
        <style>
            html {
                background-color: oklch(1 0 0);
            }

            html.dark {
                background-color: oklch(0.145 0 0);
            }
            :root {
                --base-color: <?php echo e($appSettings['site_base_color'] ?? '#1656ad'); ?>;
                --footer-bgcolor: <?php echo e($appSettings['site_footer_bgcolor'] ?? '#334461'); ?>;
                --footerbottom-bgcolor: <?php echo e($appSettings['site_footer_bottom_bgcolor'] ?? '#343b54'); ?>;
                --headertop-bgcolor: <?php echo e($appSettings['site_header_top_bgcolor'] ?? '#343b54'); ?>;
                --btn-base-color: <?php echo e($appSettings['site_button_bgcolor'] ?? '#1656ad'); ?>;
                --btn-base-hover-color: <?php echo e($appSettings['site_button_hover_bgcolor'] ?? '#061f40'); ?>;
            }
        </style>

        <title inertia><?php echo e($appSettings['site_title'] ?? config('app.name')); ?></title>


        <link rel="icon" href="<?php echo e(($appSettings['favicon'] ?? '') ? asset('storage/' . $appSettings['favicon']) : asset('default/favicon.ico')); ?>" type="image/x-icon"/>
        <link rel="icon" href="<?php echo e(asset('default/favicon.svg')); ?>" type="image/svg+xml">
        <link rel="apple-touch-icon" href="<?php echo e(asset('default/apple-touch-icon.png')); ?>">

        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />

        <?php echo app('Tighten\Ziggy\BladeRouteGenerator')->generate(); ?>
        <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.tsx', "resources/js/Pages/{$page['component']}.tsx"]); ?>
        <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->head; } ?>
    </head>
    <body class="font-sans antialiased">
        <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->body; } elseif (config('inertia.use_script_element_for_initial_page')) { ?><script data-page="app" type="application/json"><?php echo json_encode($page, JSON_HEX_TAG); ?></script><div id="app"></div><?php } else { ?><div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div><?php } ?>
    </body>
</html>
<?php /**PATH D:\laragon\www\medirx\resources\views/app.blade.php ENDPATH**/ ?>