const SchoolIconSvg = (props) => (
    <svg
        width={24}
        height={24}
        className="text-[var(--base-color)]"
        focusable="false"
        aria-hidden="true"
        viewBox="0 0 24 24"
        data-testid="SchoolIcon"
        {...props}
    >
        <path d="M5 13.18v4L12 21l7-3.82v-4L12 17l-7-3.82zM12 3 1 9l11 6 9-4.91V17h2V9L12 3z" fill="currentColor" />
    </svg>
);
export default SchoolIconSvg;
